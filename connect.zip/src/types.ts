export type TabType = 'home' | 'chat' | 'games' | 'search' | 'profile' | 'video';
export type ChatModeType = 'global' | 'dm';
